module backend/go_server

go 1.24.5

require (
	github.com/golang-jwt/jwt/v5 v5.3.0
	go.mongodb.org/mongo-driver v1.17.4
	golang.org/x/crypto v0.41.0
)

require (
	github.com/golang/snappy v0.0.4 // indirect
	github.com/joho/godotenv v1.5.1
	github.com/klauspost/compress v1.16.7 // indirect
	github.com/montanaflynn/stats v0.7.1 // indirect
	github.com/xdg-go/pbkdf2 v1.0.0 // indirect
	github.com/xdg-go/scram v1.1.2 // indirect
	github.com/xdg-go/stringprep v1.0.4 // indirect
	github.com/youmark/pkcs8 v0.0.0-20240726163527-a2c0da244d78 // indirect
	golang.org/x/sync v0.16.0 // indirect
	golang.org/x/text v0.28.0 // indirect
)
